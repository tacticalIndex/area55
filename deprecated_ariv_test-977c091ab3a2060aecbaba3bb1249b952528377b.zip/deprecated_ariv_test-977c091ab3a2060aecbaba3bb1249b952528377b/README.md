# ariv_staff_activity_logger
In-game activity logging site for ARI-V staff. 

(Hosted on netlify instead of Github Pages only because webhooks are used and I don't really feel like leaking them)
